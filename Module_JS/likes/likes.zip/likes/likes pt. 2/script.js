function IncreaseNeilLikes() {
    var NeilLikes = document.querySelector("#neil-likes").innerHTML;
    NeilLikes++;
    document.querySelector("#neil-likes").innerHTML = NeilLikes
}

function IncreaseNicholeLikes() {
    var NicholeLikes = document.querySelector("#nichole-likes").innerHTML;
    NicholeLikes++;
    document.querySelector("#nichole-likes").innerHTML = NicholeLikes
}

function IncreaseJimLikes() {
    var JimLikes = document.querySelector("#jim-likes").innerHTML;
    JimLikes++;
    document.querySelector("#jim-likes").innerHTML = JimLikes
}