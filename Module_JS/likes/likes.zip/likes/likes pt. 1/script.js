function like() {
    var Likes = document.querySelector("#likes-number").innerHTML;
    Likes++;
    document.querySelector("#likes-number").innerHTML = Likes
}