function hide(element) {
    element.remove();
}

function login(element) {
    element.innerText = "Logout";
}
